function [vin] = dc_sweep(i)

if i == 1
    vin = -10;
elseif i == 2
    vin = -9;
elseif i == 3
    vin = -8;
elseif i == 4
    vin = -7;
elseif i == 5
    vin = -6;    
elseif i == 6
    vin = -5;
elseif i == 7
    vin = -4;
elseif i == 8
    vin = -3;
elseif i == 9
    vin = -2;
elseif i == 10
    vin = -1;
elseif i == 11
    vin = 0;    
elseif i == 12
    vin = 1;
elseif i == 13
    vin = 2;
elseif i == 14
    vin = 3; 
elseif i == 15
    vin = 4;    
elseif i == 16
    vin = 5;    
elseif i == 17
    vin = 6;
elseif i == 18
    vin = 7;    
elseif i == 19
    vin = 8;    
elseif i == 20
    vin = 9;    
elseif i == 21
    vin = 10;    
end    
       
end    
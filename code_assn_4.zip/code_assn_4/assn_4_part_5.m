clc; close all; clear all;

NrNodes = 5;

global G C b L; %define global variables

X(:,1) = zeros(8,1);
v_in(:,1) = 0;
v_out(:,1) = 0;

%Netlist
G = zeros(NrNodes,NrNodes); 
C = zeros(NrNodes,NrNodes);
b = zeros(NrNodes,1);
L = zeros(NrNodes,NrNodes);
R1 = 1;  %Ohms
R2 = 2;  %Ohms
R3 = 10;  %Ohms
R4 = 0.1;  %Ohms
Ro = 1000;  %Ohms
C1 = 0.25;  %Farads
Cn = 0.00001;
L1 = 0.2;  %Henry
alpha = 100;

type = 2;   

f = 1/0.03;
h = 0.0001;
t = linspace(0, 1, 1/h);

[vin, curr] = PWL(1,type, f);
vol(1,0, vin)
res(1,2,R1)
cap(1,2,C1)
res(2,0,R2)
ind(2,3,L1)
res(3,0,R3)
cap(0,3,Cn)
cur(3,0,0.001)
res(4,5,R4)
res(5,0,Ro)
vcvs(4,0,3,0,alpha/R3)

Vout = zeros(10001,1);
vin_a = zeros(10001,1);
for i = 2:(numel(t))
    [vin, curr] = PWL(i, type, f);
    b(6) = vin;
    b(3) = curr;
    X(:,i) = ((C/h) + G) \ ((C/h)*X(:,i-1) + b(:,1));
    v_out(i) = X(5,i);
    v_in(i) = vin;
end

figure(1);  
plot(t, v_out,'b','LineWidth',2);
hold on
plot(t, v_in,'g','LineWidth',2);
grid;
title('Backwards Euler Solution with noise', 'FontSize',14);
xlabel('Time (s)','FontSize',14);
ylabel('Amplitude (V)','FontSize',14);
legend({'Vout','Vin'},'Location','northeast')

f_in =  fft(v_in);
f_out = fft(v_out);
f_in_shift =  fftshift(f_in);
f_out_shift =  fftshift(f_out);
figure(6)
plot(t, 20*log(f_in_shift))
ylabel("Gain (dB)")
xlabel("Frequency (Hz)")
title("Gaussian Input Frequency Content")
figure(7)
plot(t, 20*log(f_out_shift))
ylabel("Gain (dB)")
xlabel("Frequency (Hz)")
title("Gaussian Output Frequency Content")

function [val, current] = PWL(t,type,f)

if type == 1
    t1 = 300;
    if t < t1
        val = 0;
    elseif t == t1
        val = 1;
    else 
        val = 1;
    end
    current = 0.0005.*randn + 0.0001;
end

if type == 2
    val = sin(2 * pi * f * t/10000);
    current = 0.0005.*randn + 0.0001;
end
if type == 3
    val = 37.6* (1/(15*sqrt(2*pi))*exp((-1/2)*(((t-90)/15))^2));
    current = 0.0005.*randn + 0.0001;
end

end 


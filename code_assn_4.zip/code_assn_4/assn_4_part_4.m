clc; close all; clear all;

NrNodes = 5;

global G C b L; %define global variables

X(:,1) = zeros(8,1);
v_in(:,1) = 0;
v_out(:,1) = 0;
n = 1;


%Netlist
G = zeros(NrNodes,NrNodes); 
C = zeros(NrNodes,NrNodes);
b = zeros(NrNodes,1);
L = zeros(NrNodes,NrNodes);
R1 = 1;  %Ohms
R2 = 2;  %Ohms
R3 = 10;  %Ohms
R4 = 0.1;  %Ohms
Ro = 1000;  %Ohms
C1 = 0.25;  %Farads
L1 = 0.2;  %Henry
alpha = 100;

%type = 1;  % for step
% type =2;    % for sine
type = 3;   % for pulse

f = 1/0.03;
h = 0.001;
t = linspace(0, 1, 1/h);

vin = PWL(1,type, f);
vol(1,0, vin)
res(1,2,R1)
cap(1,2,C1)
res(2,0,R2)
ind(2,3,L1)
res(3,0,R3)
res(4,5,R4)
res(5,0,Ro)
vcvs(4,0,3,0,alpha/R3)
X(:,1) = 0;

Vout = zeros(1001,1);
vin_a = zeros(1001,1);
for i = 2:(numel(t))
    vin = PWL(i, type, f);
    b(6) = vin;
    X(:,i) = ((C/h) + G) \ ((C/h)*X(:,i-1) + b(:,1));
    v_out(i) = X(5,i);
    v_in(i) = vin;
end

figure(1);  
plot(t, v_out,'b','LineWidth',2);
hold on
plot(t, v_in,'g','LineWidth',2);
grid;
title('Backwards Euler Solution', 'FontSize',14);
xlabel('Time (s)','FontSize',14);
ylabel('Amplitude (V)','FontSize',14);
legend({'Vout','Vin'},'Location','northeast')

f_in =  fft(v_in);
f_out = fft(v_out);
f_in_shift =  fftshift(f_in);
f_out_shift =  fftshift(f_out);
figure(6)
plot(t, 20*log(f_in_shift))
ylabel("Gain (dB)")
xlabel("Frequency (Hz)")
title("Gaussian Input Frequency Content")
figure(7)
plot(t, 20*log(f_out_shift))
ylabel("Gain (dB)")
xlabel("Frequency (Hz)")
title("Gaussian Output Frequency Content")

function [val] = PWL(t,type,f)


if type == 1
    t1 = 30;
    if t < t1
        val = 0;
    elseif t == t1
        val = 1;
    else 
        val = 1;
    end
end

if type == 2
    val = sin(2 * pi * f * t/1000);
end

if type == 3
       val = 37.6* (1/(15*sqrt(2*pi))*exp((-1/2)*(((t-90)/15))^2));
end

end 


